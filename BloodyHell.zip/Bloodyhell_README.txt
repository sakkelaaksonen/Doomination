Bloodyhell.wad

Author: Sakari Laaksonen
Built with: Doom Builder, GZDoom
For: GZDoom Doom2 (not tested with vanilla Doom 2)
Difficulties: All, but really built for UV
Story: Just another overrun remote TNT project lab in the Jupiter moons. Needs to be cleared up because UAC wants to continue mining the hellscape. 

First part of my Doom 2 Eternal : Rip & Tear - wadset ( Bloody Hell, TechnoMaze  and Impstagib)

Lots and lots of monsters and some juicy secrets.
Stay alert and have fun :)

Any comments and  bug reports are appreciated, mail me at sakke.laaksonen@gmail.com